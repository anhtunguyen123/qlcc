package com.example.QuanLyCongCuBE;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuanLyCongCuBeApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuanLyCongCuBeApplication.class, args);
	}

}
