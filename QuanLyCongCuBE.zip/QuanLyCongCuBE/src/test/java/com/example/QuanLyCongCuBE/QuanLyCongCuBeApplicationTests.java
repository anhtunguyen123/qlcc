package com.example.QuanLyCongCuBE;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuanLyCongCuBeApplicationTests {

	@Test
	void contextLoads() {
	}

}
